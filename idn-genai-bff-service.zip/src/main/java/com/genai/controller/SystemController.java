package com.genai.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.genai.model.CommandRequest;

import reactor.core.publisher.Mono;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/")
public class SystemController {

    @Value("${spring.public-ip-server}")
    private String publicIpServer;

    @GetMapping("/")
    public Mono<ResponseEntity<?>> healthCheck() {
        return Mono.just(ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body("{\"status\": \"up\"}"));
    }

    @GetMapping("/check")
    public Mono<ResponseEntity<?>> checkConnectivity(@RequestParam String target,
            @RequestParam(defaultValue = "80") int port) {
        return Mono.fromCallable(() -> {
            boolean reachable = isReachable(target, port);
            String currentIp = getCurrentIpAddress();
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(
                    String.format("{\"source\": \"%s\", \"target\": \"%s\", \"port\": %d, \"reachable\": %b}",
                            currentIp, target, port, reachable));
        });
    }

    private boolean isReachable(String target, int port) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(target, port), 2000);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private String getCurrentIpAddress() {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(publicIpServer))
                .GET()
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            return response.body().trim();
        } catch (IOException | InterruptedException e) {
            Thread.currentThread().interrupt();
            return "unknown";
        }
    }

    @GetMapping("/{filename}")
    public Mono<ResponseEntity<Resource>> getStaticResource(@PathVariable String filename) {
        return Mono.fromCallable(() -> {
            Resource resource = new ClassPathResource("public/" + filename);
            if (!resource.exists()) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok().body(resource);
        });
    }

    @PostMapping("/command")
    public Mono<ResponseEntity<?>> executeCommand(@RequestBody CommandRequest request) {
        return Mono.fromSupplier(() -> ResponseEntity.ok(runCommand(request.getCommand())));
    }

    private String runCommand(String command) {
        try {
            ProcessBuilder processBuilder;
            if (isWindows()) {
                processBuilder = new ProcessBuilder("cmd.exe", "/c", command);
            } else {
                processBuilder = new ProcessBuilder("sh", "-c", command);
            }
            Process process = processBuilder.start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                return reader.lines().collect(Collectors.joining("\n"));
            }
        } catch (IOException e) {
            return "Error executing command: " + e.getMessage();
        }
    }

    private boolean isWindows() {
        return System.getProperty("os.name").toLowerCase().contains("win");
    }
}
