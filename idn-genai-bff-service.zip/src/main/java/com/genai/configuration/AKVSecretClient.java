package com.genai.configuration;

public interface AKVSecretClient {
	public String getSecretValue(String secretName, String defaultValue);
}
