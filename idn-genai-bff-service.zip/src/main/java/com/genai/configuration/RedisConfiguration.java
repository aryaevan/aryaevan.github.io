package com.genai.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration.JedisClientConfigurationBuilder;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import java.time.Duration;

@Configuration
public class RedisConfiguration {

    @Value("${azure.redis.host}")
    private String host;

    @Value("${azure.redis.key}")
    private String key;

    @Value("${azure.redis.scope}")
    private String scope;

    @Value("${azure.redis.port}")
    private int port;

    // Only Premium or Enterprise SKU that support connect via RBAC. Use key for now
    // private final ClientSecretCredential azureCredential;

    // public RedisConfiguration(ClientSecretCredential azureCredential) {
    //     this.azureCredential = azureCredential;
    // }
    
    @Bean
    public JedisConnectionFactory jedisConnectionFactory() {

        // String accessToken = azureCredential.getToken(
        //         new TokenRequestContext()
        //                 .addScopes(scope))
        //         .block().getToken();

        RedisStandaloneConfiguration config = new RedisStandaloneConfiguration();
        config.setHostName(host);
        config.setPort(port);
        // config.setPassword(accessToken); 
        config.setPassword(key);

        JedisClientConfiguration clientConfig = ((JedisClientConfigurationBuilder) JedisClientConfiguration.builder()
                .useSsl())
                .connectTimeout(Duration.ofSeconds(10))
                .build();

        return new JedisConnectionFactory(config, clientConfig);
    }

    @Bean
    public RedisTemplate<String, Object> redisTemplate() {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(jedisConnectionFactory());
        return template;
    }
}
