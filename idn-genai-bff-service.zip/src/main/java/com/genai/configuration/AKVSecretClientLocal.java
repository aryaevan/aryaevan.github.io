package com.genai.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("local")
public class AKVSecretClientLocal {
	public String getSecretValue(String secretName, String defaultValue) {
        return defaultValue;
    }
}
