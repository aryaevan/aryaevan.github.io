package com.genai.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AzureStorageConfiguration<CloudBlobContainer> {
	
	@Value("${azure.storage.connection-string}")
	private String connectionString;
	
	@Value("${azure.storage.container-name}")
	private String containerName;
	
	@Bean
	public CloudBlobContainer cloudBlobContainer() throws Exception{
//		CloudStorageAccount storageAccount = CloudStorageAccount.parse(akvSecretClient.)
		return null;
	}
}
