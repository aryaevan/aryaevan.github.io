## Building
```shell
mvn clean package
```

## Running
```shell
mvn clean spring-boot:run
```

## Generate snyk report (.html)
```shell
snyk-test.bat
```

## Generate jacoco | code coverage report (.html)
```shell
mvn clean verify
```

## Service Status
```shell
http://localhost:8080
```

## Swagger
```shell
http://localhost:8080/swagger.html
```


