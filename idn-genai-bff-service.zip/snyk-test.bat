echo off
echo "Running Snyk tests"
snyk-win test --json > snyk.json 
echo "Provide Snyk HTML report"
snyk-to-html -i snyk.json -o snyk.html 
echo "Snyk tests completed"
exit 0